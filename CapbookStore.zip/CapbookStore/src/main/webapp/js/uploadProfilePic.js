'use strict';

var singleUploadForm = document.querySelector('#singleUploadForm');
function uploadSingleFile(file) {
    var formData = new FormData();
    formData.append("file", file);
    formData.append("albumName","profile");

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/uploadFile");
    xhr.send(formData);
}