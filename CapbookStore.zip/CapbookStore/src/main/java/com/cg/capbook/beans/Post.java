package com.cg.capbook.beans;
import java.util.Map;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int postId;
	private String statusBody;
	private int likeCount;
	private int dislikeCount;
	@OneToMany(mappedBy="post",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,Likes>likes;
	@OneToMany(mappedBy="post",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,Comment>comments;
	@ManyToOne
	private UserProfile user;
	
	public Post() {}

	

	public Post(String statusBody, int likeCount, int dislikeCount, Map<Integer, Likes> likes,
			Map<Integer, Comment> comments) {
		super();
		this.statusBody = statusBody;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.likes = likes;
		this.comments = comments;
	}


	public Post(String statusBody, int likeCount, int dislikeCount, Map<Integer, Likes> likes,
			Map<Integer, Comment> comments, UserProfile user) {
		super();
		this.statusBody = statusBody;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.likes = likes;
		this.comments = comments;
		this.user = user;
	}

	public int getpostId() {
		return postId;
	}

	public void setpostId(int postId) {
		this.postId = postId;
	}

	public String getStatusBody() {
		return statusBody;
	}

	public void setStatusBody(String statusBody) {
		this.statusBody = statusBody;
	}

	public int getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public int getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	public Map<Integer, Likes> getLikes() {
		return likes;
	}

	public void setLikes(Map<Integer, Likes> likes) {
		this.likes = likes;
	}

	public Map<Integer, Comment> getComments() {
		return comments;
	}

	public void setComments(Map<Integer, Comment> comments) {
		this.comments = comments;
	}

	public UserProfile getUser() {
		return user;
	}

	public void setUser(UserProfile user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comments == null) ? 0 : comments.hashCode());
		result = prime * result + dislikeCount;
		result = prime * result + likeCount;
		result = prime * result + ((likes == null) ? 0 : likes.hashCode());
		result = prime * result + ((statusBody == null) ? 0 : statusBody.hashCode());
		result = prime * result + postId;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Post other = (Post) obj;
		if (comments == null) {
			if (other.comments != null)
				return false;
		} else if (!comments.equals(other.comments))
			return false;
		if (dislikeCount != other.dislikeCount)
			return false;
		if (likeCount != other.likeCount)
			return false;
		if (likes == null) {
			if (other.likes != null)
				return false;
		} else if (!likes.equals(other.likes))
			return false;
		if (statusBody == null) {
			if (other.statusBody != null)
				return false;
		} else if (!statusBody.equals(other.statusBody))
			return false;
		if (postId != other.postId)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Status [postId=" + postId + ", statusBody=" + statusBody + ", likeCount=" + likeCount
				+ ", dislikeCount=" + dislikeCount + ", likes=" + likes + ", comments=" + comments + "]";
	}

	
	
}
