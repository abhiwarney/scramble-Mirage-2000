package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.InvalidEmailException;
import com.cg.capbook.exceptions.InvalidPasswordException;
@Component("loginService")
public class LoginServicesImpl implements LoginService{
@Autowired
UserProfileServices userProfileServices;
	@Override
	public UserProfile loginUser(String email, String password) throws InvalidEmailException, InvalidPasswordException {
		UserProfile user =userProfileServices.getUserProfileDetailsByEmail(email);
		if(user.getPassword().equals(password))
		return user;
	else
		throw new InvalidPasswordException("Incorrect Password,Please Enter Correct Password!");
		
	}

}
