package com.cg.capbook.exceptions;

public class UserProfileNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3811191412568365465L;

	public UserProfileNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserProfileNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UserProfileNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserProfileNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserProfileNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
