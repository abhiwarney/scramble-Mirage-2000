package com.cg.capbook.beans;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Message{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int message_Id;
	private String text;
	private LocalDateTime date=LocalDateTime.now();
	@ManyToOne
	private Chat chat;
	
	public Message() {}
	
	public Message(String text, LocalDateTime date, Chat chat) {
		super();
		this.text = text;
		this.date = date;
		this.chat = chat;
	}

	public Message(String text, LocalDateTime date) {
		super();
		this.text = text;
		this.date = date;
	}
	public int getMessage_Id() {
		return message_Id;
	}

	public void setMessage_Id(int message_Id) {
		this.message_Id = message_Id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public Chat getChat() {
		return chat;
	}

	public void setChat(Chat chat) {
		this.chat = chat;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((chat == null) ? 0 : chat.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + message_Id;
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Message other = (Message) obj;
		if (chat == null) {
			if (other.chat != null)
				return false;
		} else if (!chat.equals(other.chat))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (message_Id != other.message_Id)
			return false;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Message [message_Id=" + message_Id + ", text=" + text + ", date=" + date + "]";
	}


	
}
