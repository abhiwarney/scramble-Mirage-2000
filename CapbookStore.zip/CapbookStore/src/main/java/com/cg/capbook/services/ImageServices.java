package com.cg.capbook.services;

import com.cg.capbook.beans.Image;

public interface ImageServices {
	Image saveImage(Image image);
	Image updateImage(int userId,Image image);
	Image getImageByName(int userId,String imageName);
	boolean deleteImage(int userId,String imageName);
}
