package com.cg.capbook.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.daoservices.UserProfileDao;
import com.cg.capbook.exceptions.InvalidEmailException;
import com.cg.capbook.exceptions.UserAlreadyExistException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;
@Component("userProfileServices")
public class UserProfileServicesImpl implements UserProfileServices{
	@Autowired
	UserProfileDao userProfileDao;

	@Override
	public UserProfile acceptUserProfileDetails(UserProfile user)throws UserAlreadyExistException{
		if(userProfileDao.findByEmailId(user.getEmailId())!=null)
			throw new UserAlreadyExistException("User Already Exist!");
		return userProfileDao.save(user);
	}
	@Override
	public UserProfile getUserProfileDetails(int userId)throws UserProfileNotFoundException{
		return userProfileDao.findById(userId).orElseThrow(()->new UserProfileNotFoundException("Invalid User Id"));
	}



	@Override
	public boolean updateUserProfileDetails(UserProfile user)throws UserProfileNotFoundException {
		getUserProfileDetails(user.getUserId());
		userProfileDao.save(user);
		return true;
	}

	@Override
	public boolean deleteUserProfileDetails(int userId)throws UserProfileNotFoundException {
		userProfileDao.delete(getUserProfileDetails(userId));
		return true;
	}
	@Override
	public UserProfile getUserProfileDetailsByEmail(String emailId)throws InvalidEmailException {
		UserProfile user=userProfileDao.findByEmailId(emailId);
		if(user==null)
			throw new InvalidEmailException("Invalid Email or User Does not Exist!");
		return user;
	}

}
