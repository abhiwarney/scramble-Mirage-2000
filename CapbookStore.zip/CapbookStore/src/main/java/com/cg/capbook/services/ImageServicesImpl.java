package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Image;
import com.cg.capbook.daoservices.ImageDao;
import com.cg.capbook.exceptions.ImageDetailsNotFoundException;
@Component("imageServices")
public class ImageServicesImpl implements ImageServices{
	@Autowired
	ImageDao imageDao;
	@Autowired
	UserProfileServices userProfileServices;
	@Override
	public Image saveImage(Image image) {
		return imageDao.save(image);
	}

	@Override
	public Image updateImage(int userId, Image image)throws ImageDetailsNotFoundException {
		getImageByName(userId, image.getfileName());
		return imageDao.save(image);
	}

	@Override
	public Image getImageByName(int userId, String imageName) {
		Image image= imageDao.getImageByName(imageName, userId);
		if(image==null)
			throw new ImageDetailsNotFoundException("Image Details Not Found!");
		return image;
	}

	@Override
	public boolean deleteImage(int userId, String imageName) {
		Image image=getImageByName(userId, imageName);
		imageDao.deleteById(image.getImageId());
		return true;
	}

}
