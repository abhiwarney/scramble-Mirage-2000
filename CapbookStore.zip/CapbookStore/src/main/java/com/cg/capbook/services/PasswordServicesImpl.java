package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.InvalidCurrentPasswordException;
import com.cg.capbook.exceptions.InvalidSecurityAnswerException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;
@Component("passwordServices")
public class PasswordServicesImpl implements PasswordServices{
	@Autowired
	UserProfileServices userProfileServices;
	@Override
	public String forgotUserPassword(String emailId,String securityQuestion,String securityAnswer)throws UserProfileNotFoundException,InvalidSecurityAnswerException {
		UserProfile user=userProfileServices.getUserProfileDetailsByEmail(emailId);
		if(user.getSecurityQuestion().equalsIgnoreCase(securityQuestion)&&user.getSecurityAnswer().equalsIgnoreCase(securityAnswer))
		return user.getPassword();
		else 
			throw new InvalidSecurityAnswerException("InvalidSecurityAnswer!!");
	}

	@Override
	public boolean changeUserPassword(int userId, String newPassword,String currentPassword) throws InvalidCurrentPasswordException{
		UserProfile user=userProfileServices.getUserProfileDetails(userId);
		if(user.getPassword().equals(currentPassword)==false)
			throw new InvalidCurrentPasswordException("Invalid Current password Entered");
		else {
			user.setPassword(newPassword);
			userProfileServices.updateUserProfileDetails(user);
		}
		return true;
	}

}
