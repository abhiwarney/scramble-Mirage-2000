package com.cg.capbook.services;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.exceptions.FileStorageException;

import java.nio.file.Path;
import java.util.stream.Stream;

public interface StorageService {

    void init();

  String store(MultipartFile file) throws FileStorageException;

    Stream<Path> loadAll();

    Path load(String filename);

    Resource loadFileAsResource(String filename);

    void deleteAll();

}
