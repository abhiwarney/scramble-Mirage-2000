package com.cg.capbook.beans;
import java.util.Map;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class ForumPost {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int forumPostId;
	private int postCreatedby;
	private String postDescription;
	private int likeCount;
	private int dislikeCount;
	@ManyToOne
	private Forum forum;
	@OneToMany(mappedBy="forumPost",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,ForumLike>likes;
	@OneToMany(mappedBy="forumPost",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,ForumComment>comments;
	
	public ForumPost() {}

	public ForumPost(int postCreatedby, String postDescription, int likeCount, int dislikeCount, Forum forum,
			Map<Integer, ForumLike> likes, Map<Integer, ForumComment> comments) {
		super();
		this.postCreatedby = postCreatedby;
		this.postDescription = postDescription;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.forum = forum;
		this.likes = likes;
		this.comments = comments;
	}

	public ForumPost(int postCreatedby, String postDescription, int likeCount, int dislikeCount, Forum forum) {
		super();
		this.postCreatedby = postCreatedby;
		this.postDescription = postDescription;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.forum = forum;
	}

	public ForumPost(int postCreatedby, String postDescription, int likeCount, int dislikeCount) {
		super();
		this.postCreatedby = postCreatedby;
		this.postDescription = postDescription;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
	}

	public int getForumPostId() {
		return forumPostId;
	}

	public void setForumPostId(int forumPostId) {
		this.forumPostId = forumPostId;
	}

	public int getPostCreatedby() {
		return postCreatedby;
	}

	public void setPostCreatedby(int postCreatedby) {
		this.postCreatedby = postCreatedby;
	}

	public String getPostDescription() {
		return postDescription;
	}

	public void setPostDescription(String postDescription) {
		this.postDescription = postDescription;
	}

	public int getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public int getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	public Forum getForum() {
		return forum;
	}

	public void setForum(Forum forum) {
		this.forum = forum;
	}

	public Map<Integer, ForumLike> getLikes() {
		return likes;
	}

	public void setLikes(Map<Integer, ForumLike> likes) {
		this.likes = likes;
	}

	public Map<Integer, ForumComment> getComments() {
		return comments;
	}

	public void setComments(Map<Integer, ForumComment> comments) {
		this.comments = comments;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comments == null) ? 0 : comments.hashCode());
		result = prime * result + dislikeCount;
		result = prime * result + ((forum == null) ? 0 : forum.hashCode());
		result = prime * result + forumPostId;
		result = prime * result + likeCount;
		result = prime * result + ((likes == null) ? 0 : likes.hashCode());
		result = prime * result + postCreatedby;
		result = prime * result + ((postDescription == null) ? 0 : postDescription.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ForumPost other = (ForumPost) obj;
		if (comments == null) {
			if (other.comments != null)
				return false;
		} else if (!comments.equals(other.comments))
			return false;
		if (dislikeCount != other.dislikeCount)
			return false;
		if (forum == null) {
			if (other.forum != null)
				return false;
		} else if (!forum.equals(other.forum))
			return false;
		if (forumPostId != other.forumPostId)
			return false;
		if (likeCount != other.likeCount)
			return false;
		if (likes == null) {
			if (other.likes != null)
				return false;
		} else if (!likes.equals(other.likes))
			return false;
		if (postCreatedby != other.postCreatedby)
			return false;
		if (postDescription == null) {
			if (other.postDescription != null)
				return false;
		} else if (!postDescription.equals(other.postDescription))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ForumPost [forumPostId=" + forumPostId + ", postCreatedby=" + postCreatedby + ", postDescription="
				+ postDescription + ", likeCount=" + likeCount + ", dislikeCount=" + dislikeCount + ", likes=" + likes
				+ ", comments=" + comments + "]";
	}

	
	
}
