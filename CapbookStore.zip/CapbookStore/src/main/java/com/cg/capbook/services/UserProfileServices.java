package com.cg.capbook.services;

import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.InvalidEmailException;
import com.cg.capbook.exceptions.UserAlreadyExistException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;

public interface UserProfileServices {
	UserProfile acceptUserProfileDetails(UserProfile user)throws UserAlreadyExistException;
	UserProfile getUserProfileDetails(int userId)throws UserProfileNotFoundException;
	UserProfile getUserProfileDetailsByEmail(String emailId)throws InvalidEmailException;
	boolean updateUserProfileDetails(UserProfile user)throws UserProfileNotFoundException;
	boolean deleteUserProfileDetails(int userId)throws UserProfileNotFoundException;
}
